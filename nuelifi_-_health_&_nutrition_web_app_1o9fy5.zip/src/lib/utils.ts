export function cn(
  ...inputs: Array<string | false | null | undefined>
): string {
  return inputs.filter(Boolean).join(' ')
}

export function formatTime(date: Date): string {
  return new Intl.DateTimeFormat('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  }).format(date)
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  }).format(date)
}

export function formatDateLong(date: Date): string {
  return new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  }).format(date)
}

export function getProgressColor(
  value: number,
  target: number,
): string {
  if (target <= 0) return 'text-error'

  const ratio = value / target

  if (ratio >= 1) return 'text-success'
  if (ratio >= 0.75) return 'text-primary'
  if (ratio >= 0.5) return 'text-warning'

  return 'text-error'
}
