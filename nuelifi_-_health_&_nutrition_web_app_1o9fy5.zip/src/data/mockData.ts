import { Meal, Recommendation, UserProfile, DailyStats, TrendData } from '../types';

export const mockUser: UserProfile = {
  name: 'Alex Chen',
  email: 'alex.chen@example.com',
  plan: 'free',
  avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=200',
  goals: ['Weight management', 'Reduce inflammation', 'Better energy'],
  dietaryRestrictions: ['Gluten-free', 'Low sodium'],
  healthConditions: ['Pre-diabetes', 'Hypertension'],
};

export const mockMeals: Meal[] = [
  {
    id: '1',
    name: 'Grilled Salmon Bowl',
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800',
    timestamp: new Date('2025-01-15T12:30:00'),
    status: 'healthy',
    nutrition: { calories: 420, protein: 35, carbs: 28, fat: 18, fiber: 8, sugar: 4, sodium: 380 },
    analysis: {
      summary: 'Excellent balanced meal with high-quality protein, healthy fats, and fiber-rich vegetables.',
      strengths: ['High omega-3 from salmon', 'Good fiber content', 'Low added sugar', 'Balanced macros'],
      concerns: ['Slightly high sodium from soy sauce'],
      modifications: ['Use low-sodium tamari instead of soy sauce', 'Add more leafy greens for volume'],
    },
    recommendations: [
      { id: 'r1', title: 'Take a 15-min walk after lunch', description: 'Helps glucose regulation after meals', category: 'activity', priority: 'high', completed: true, dueDate: new Date('2025-01-15T13:00:00'), relatedMealId: '1' },
      { id: 'r2', title: 'Drink 500ml water', description: 'Supports digestion and hydration', category: 'hydration', priority: 'medium', completed: false, dueDate: new Date('2025-01-15T14:00:00'), relatedMealId: '1' },
    ],
  },
  {
    id: '2',
    name: 'Chicken Caesar Wrap',
    image: 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg?auto=compress&cs=tinysrgb&w=800',
    timestamp: new Date('2025-01-15T19:00:00'),
    status: 'moderate',
    nutrition: { calories: 580, protein: 32, carbs: 45, fat: 28, fiber: 5, sugar: 6, sodium: 890 },
    analysis: {
      summary: 'Decent protein but high in sodium and refined carbs. Dressing adds hidden calories.',
      strengths: ['Good protein portion', 'Contains vegetables'],
      concerns: ['High sodium (890mg)', 'Refined flour wrap', 'Creamy dressing adds saturated fat'],
      modifications: ['Swap wrap for lettuce leaves or whole grain', 'Use Greek yogurt-based dressing', 'Add more colorful veggies'],
    },
    recommendations: [
      { id: 'r3', title: 'Evening walk 20 mins', description: 'Counteracts post-dinner glucose spike', category: 'activity', priority: 'high', completed: false, dueDate: new Date('2025-01-15T20:00:00'), relatedMealId: '2' },
      { id: 'r4', title: 'Limit sodium tomorrow', description: 'Target <1500mg after high-sodium meal', category: 'nutrition', priority: 'high', completed: false, dueDate: new Date('2025-01-16T23:59:00'), relatedMealId: '2' },
    ],
  },
  {
    id: '3',
    name: 'Greek Yogurt Parfait',
    image: 'https://images.pexels.com/photos/1488463/pexels-photo-1488463.jpeg?auto=compress&cs=tinysrgb&w=800',
    timestamp: new Date('2025-01-14T08:00:00'),
    status: 'healthy',
    nutrition: { calories: 320, protein: 28, carbs: 35, fat: 8, fiber: 6, sugar: 18, sodium: 120 },
    analysis: {
      summary: 'Protein-rich breakfast with probiotics. Watch added sugars in granola.',
      strengths: ['High protein', 'Probiotics for gut health', 'Berries provide antioxidants'],
      concerns: ['Granola may have added sugars'],
      modifications: ['Choose unsweetened granola', 'Add chia seeds for omega-3'],
    },
    recommendations: [
      { id: 'r5', title: 'Morning hydration', description: 'Drink 300ml water upon waking', category: 'hydration', priority: 'medium', completed: true, dueDate: new Date('2025-01-14T08:30:00'), relatedMealId: '3' },
    ],
  },
  {
    id: '4',
    name: 'Pepperoni Pizza Slice',
    image: 'https://images.pexels.com/photos/2147491/pexels-photo-2147491.jpeg?auto=compress&cs=tinysrgb&w=800',
    timestamp: new Date('2025-01-14T13:00:00'),
    status: 'unhealthy',
    nutrition: { calories: 380, protein: 14, carbs: 36, fat: 18, fiber: 2, sugar: 5, sodium: 920 },
    analysis: {
      summary: 'High in refined carbs, saturated fat, and sodium. Low nutritional density.',
      strengths: ['Some protein from cheese'],
      concerns: ['Very high sodium', 'Refined flour crust', 'Processed meat', 'Low fiber'],
      modifications: ['Choose thin crust with veggie toppings', 'Add side salad', 'Limit to once per week'],
    },
    recommendations: [
      { id: 'r6', title: 'Extra 30 min activity today', description: 'Balance the calorie surplus', category: 'activity', priority: 'high', completed: false, dueDate: new Date('2025-01-14T18:00:00'), relatedMealId: '4' },
      { id: 'r7', title: 'High potassium dinner', description: 'Counteract sodium with potassium-rich foods', category: 'nutrition', priority: 'high', completed: false, dueDate: new Date('2025-01-14T19:00:00'), relatedMealId: '4' },
    ],
  },
];

export const mockRecommendations: Recommendation[] = [
  { id: 'r1', title: 'Take a 15-min walk after lunch', description: 'Helps glucose regulation after meals', category: 'activity', priority: 'high', completed: true, dueDate: new Date('2025-01-15T13:00:00'), relatedMealId: '1' },
  { id: 'r2', title: 'Drink 500ml water', description: 'Supports digestion and hydration', category: 'hydration', priority: 'medium', completed: false, dueDate: new Date('2025-01-15T14:00:00'), relatedMealId: '1' },
  { id: 'r3', title: 'Evening walk 20 mins', description: 'Counteracts post-dinner glucose spike', category: 'activity', priority: 'high', completed: false, dueDate: new Date('2025-01-15T20:00:00'), relatedMealId: '2' },
  { id: 'r4', title: 'Limit sodium tomorrow', description: 'Target <1500mg after high-sodium meal', category: 'nutrition', priority: 'high', completed: false, dueDate: new Date('2025-01-16T23:59:00'), relatedMealId: '2' },
  { id: 'r5', title: 'Morning hydration', description: 'Drink 300ml water upon waking', category: 'hydration', priority: 'medium', completed: true, dueDate: new Date('2025-01-14T08:30:00'), relatedMealId: '3' },
  { id: 'r6', title: 'Extra 30 min activity today', description: 'Balance the calorie surplus', category: 'activity', priority: 'high', completed: false, dueDate: new Date('2025-01-14T18:00:00'), relatedMealId: '4' },
  { id: 'r7', title: 'High potassium dinner', description: 'Counteract sodium with potassium-rich foods', category: 'nutrition', priority: 'high', completed: false, dueDate: new Date('2025-01-14T19:00:00'), relatedMealId: '4' },
  { id: 'r8', title: 'Prep overnight oats', description: 'Healthy breakfast ready for tomorrow', category: 'nutrition', priority: 'medium', completed: false, dueDate: new Date('2025-01-16T07:00:00') },
  { id: 'r9', title: 'Bedtime by 10:30 PM', description: 'Consistent sleep supports metabolic health', category: 'sleep', priority: 'medium', completed: false, dueDate: new Date('2025-01-15T22:30:00') },
];

export const mockDailyStats: DailyStats = {
  calories: { current: 1700, target: 2000 },
  protein: { current: 109, target: 120 },
  carbs: { current: 144, target: 200 },
  fat: { current: 72, target: 70 },
  water: { current: 1.8, target: 3.0 },
  steps: { current: 6200, target: 8000 },
  sleep: { current: 7.2, target: 8.0 },
};

export const mockTrends: TrendData[] = [
  { date: '2025-01-09', calories: 1850, protein: 95, carbs: 180, fat: 78, score: 72 },
  { date: '2025-01-10', calories: 1920, protein: 102, carbs: 195, fat: 72, score: 78 },
  { date: '2025-01-11', calories: 2100, protein: 88, carbs: 220, fat: 85, score: 65 },
  { date: '2025-01-12', calories: 1780, protein: 110, carbs: 165, fat: 68, score: 82 },
  { date: '2025-01-13', calories: 2050, protein: 92, carbs: 210, fat: 82, score: 70 },
  { date: '2025-01-14', calories: 1950, protein: 105, carbs: 185, fat: 75, score: 76 },
  { date: '2025-01-15', calories: 1700, protein: 109, carbs: 144, fat: 72, score: 85 },
];
