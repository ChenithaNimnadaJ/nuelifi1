import { useAppState } from '../hooks/useAppState'
import { Dashboard } from './dashboard/Dashboard'
import { OnboardingFlow } from './onboarding/OnboardingFlow'

export default function Layout() {
  const { currentScreen } = useAppState()

  if (currentScreen === 'onboarding') {
    return <OnboardingFlow />
  }

  return <Dashboard />
}
