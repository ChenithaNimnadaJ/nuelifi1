import { Fragment, ReactNode } from 'react';
import { X } from 'lucide-react';
import { cn } from '../../lib/utils';
import { Button } from './Button';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  description?: string;
  children: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
}

export function Modal({ isOpen, onClose, title, description, children, size = 'md' }: ModalProps) {
  if (!isOpen) return null;

  const sizes = {
    sm: 'max-w-md',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl',
    full: 'max-w-[90vw]',
  };

  return (
    <Fragment>
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 animate-fade-in"
        onClick={onClose}
        aria-hidden="true"
      />
      <div className={cn(
        'fixed inset-0 z-50 flex items-center justify-center p-4 animate-slide-up',
        sizes[size]
      )}>
        <div className="w-full bg-surface rounded-2xl border border-border shadow-2xl shadow-black/30 overflow-hidden">
          {(title || description) && (
            <div className="px-6 py-4 border-b border-border flex items-start justify-between gap-4">
              <div>
                {title && <h2 className="text-xl font-semibold text-text">{title}</h2>}
                {description && <p className="text-textSecondary text-sm mt-1">{description}</p>}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                aria-label="Close modal"
                className="p-1 hover:bg-border rounded-xl"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          )}
          <div className="p-6 max-h-[70vh] overflow-y-auto">
            {children}
          </div>
        </div>
      </div>
    </Fragment>
  );
}
