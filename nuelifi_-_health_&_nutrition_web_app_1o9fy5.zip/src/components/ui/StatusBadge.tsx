import { cn } from '../../lib/utils';

type Status = 'healthy' | 'moderate' | 'unhealthy';

interface StatusBadgeProps {
  status: Status;
  size?: 'sm' | 'md' | 'lg';
}

const statusConfig = {
  healthy: { 
    label: 'Healthy', 
    bg: 'bg-success/15', 
    text: 'text-success', 
    border: 'border-success/30',
    icon: '🟢'
  },
  moderate: { 
    label: 'Moderate', 
    bg: 'bg-warning/15', 
    text: 'text-warning', 
    border: 'border-warning/30',
    icon: '🟡'
  },
  unhealthy: { 
    label: 'Needs Work', 
    bg: 'bg-error/15', 
    text: 'text-error', 
    border: 'border-error/30',
    icon: '🔴'
  },
};

export function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const config = statusConfig[status];
  const sizes = {
    sm: 'px-2 py-0.5 text-xs gap-1',
    md: 'px-3 py-1 text-sm gap-1.5',
    lg: 'px-4 py-1.5 text-base gap-2',
  };

  return (
    <span className={cn(
      'inline-flex items-center font-medium rounded-full border',
      config.bg, config.text, config.border,
      sizes[size]
    )}>
      <span>{config.icon}</span>
      <span>{config.label}</span>
    </span>
  );
}
