import { Meal } from '../../types'
import { formatDistanceToNow } from 'date-fns'
import { Card, CardContent } from '../ui/Card'
import { StatusBadge } from '../ui/StatusBadge'
import { cn } from '../../lib/utils'

interface MealCardProps {
  meal: Meal
  onPress?: () => void
}

export function MealCard({ meal, onPress }: MealCardProps) {
  if (!meal.analysis) return null

  const { mealName, calories, macros, healthScore, status, timestamp } = meal.analysis
  const timeAgo = formatDistanceToNow(new Date(meal.timestamp), { addSuffix: true })

  const statusColors = {
    excellent: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    good: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
    moderate: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    poor: 'bg-red-500/20 text-red-400 border-red-500/30',
  }

  return (
    <Card
      variant="elevated"
      padding="none"
      className={cn('overflow-hidden transition-all duration-200', onPress && 'cursor-pointer hover:shadow-[0_0_30px_rgba(158,127,255,0.15)]')}
      onClick={onPress}
    >
      <div className="relative h-40 w-full">
        <img
          src={meal.imageUrl}
          alt={mealName}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-transparent to-transparent" />
        <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
          <div>
            <h3 className="text-lg font-semibold text-white">{mealName}</h3>
            <p className="text-neutral-400 text-xs">{timeAgo}</p>
          </div>
          <StatusBadge
            label={status.charAt(0).toUpperCase() + status.slice(1)}
            className={statusColors[status]}
          />
        </div>
      </div>

      <CardContent className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold text-white">{calories}</span>
            <span className="text-neutral-500 text-sm">kcal</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-20 h-2 bg-neutral-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(healthScore, 100)}%` }}
              />
            </div>
            <span className="text-sm font-medium text-white w-10 text-right">{healthScore}</span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <MacroStat label="Protein" value={macros.protein} unit="g" color="#f472b6" />
          <MacroStat label="Carbs" value={macros.carbs} unit="g" color="#38bdf8" />
          <MacroStat label="Fat" value={macros.fat} unit="g" color="#fbbf24" />
        </div>

        <div className="flex items-center gap-2 text-xs text-neutral-500 pt-2 border-t border-neutral-800">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            Fiber: {macros.fiber}g
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            Sugar: {macros.sugar}g
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-red-500" />
            Sodium: {macros.sodium}mg
          </span>
        </div>
      </CardContent>
    </Card>
  )
}

function MacroStat({ label, value, unit, color }: { label: string; value: number; unit: string; color: string }) {
  return (
    <div className="text-center p-3 bg-neutral-900/50 rounded-xl">
      <p className="text-xs text-neutral-500 uppercase tracking-wider">{label}</p>
      <div className="flex items-baseline justify-center gap-0.5 mt-1">
        <span className="text-xl font-bold" style={{ color }}>{value}</span>
        <span className="text-xs text-neutral-500">{unit}</span>
      </div>
    </div>
  )
}
