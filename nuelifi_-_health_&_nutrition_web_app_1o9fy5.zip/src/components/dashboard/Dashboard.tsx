import { useAppState } from '../../hooks/useAppState'
import { Header } from '../layout/Header'
import { BottomNav } from '../layout/BottomNav'

export function Dashboard() {
  const {
    user,
    meals,
    recommendations,
    dailyStats,
    setCurrentScreen,
  } = useAppState()

  const completedRecommendations = recommendations.filter(
    item => item.completed,
  ).length

  const latestMeal = meals[0]

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />

      <main className="mx-auto w-full max-w-5xl px-4 pb-28 pt-6 md:px-6 md:pb-10">
        <div className="space-y-6">

          {/* Welcome */}
          <section>
            <p className="text-sm text-muted-foreground">
              Good morning
            </p>

            <h1 className="mt-1 text-2xl font-semibold tracking-tight md:text-3xl">
              {user?.name ? `Welcome back, ${user.name}` : 'Welcome back'}
            </h1>

            <p className="mt-2 max-w-xl text-sm text-muted-foreground">
              Small choices today can build healthier habits over time.
            </p>
          </section>

          {/* Stats */}
          <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <div className="rounded-2xl border bg-card p-4">
              <p className="text-xs text-muted-foreground">
                Meals analysed
              </p>
              <p className="mt-2 text-2xl font-semibold">
                {meals.length}
              </p>
            </div>

            <div className="rounded-2xl border bg-card p-4">
              <p className="text-xs text-muted-foreground">
                Today's progress
              </p>
              <p className="mt-2 text-2xl font-semibold">
                {dailyStats?.score ?? 78}%
              </p>
            </div>

            <div className="rounded-2xl border bg-card p-4">
              <p className="text-xs text-muted-foreground">
                Actions done
              </p>
              <p className="mt-2 text-2xl font-semibold">
                {completedRecommendations}
              </p>
            </div>

            <div className="rounded-2xl border bg-card p-4">
              <p className="text-xs text-muted-foreground">
                Plan
              </p>
              <p className="mt-2 text-2xl font-semibold capitalize">
                {user?.plan ?? 'Free'}
              </p>
            </div>
          </section>

          {/* Capture */}
          <section className="rounded-3xl border bg-card p-6 md:p-8">
            <div className="max-w-xl">
              <p className="text-sm font-medium">
                Understand your next meal
              </p>

              <h2 className="mt-2 text-xl font-semibold">
                Snap a meal and see how you can improve it.
              </h2>

              <p className="mt-2 text-sm leading-6 text-muted-foreground">
                Use a photo to get a simple assessment and practical
                suggestions. This prototype uses mock analysis.
              </p>

              <button
                onClick={() => setCurrentScreen('camera')}
                className="mt-5 rounded-xl bg-foreground px-5 py-3 text-sm font-medium text-background transition-opacity hover:opacity-80"
              >
                Analyse a meal
              </button>
            </div>
          </section>

          {/* Latest meal */}
          <section>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-lg font-semibold">
                Recent meal
              </h2>
            </div>

            {latestMeal ? (
              <div className="rounded-2xl border bg-card p-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="font-medium">
                      {latestMeal.name ?? 'Recent meal'}
                    </h3>

                    <p className="mt-1 text-sm text-muted-foreground">
                      {latestMeal.description ??
                        'Your latest analysed meal.'}
                    </p>
                  </div>

                  <span className="rounded-full border px-3 py-1 text-xs font-medium">
                    {latestMeal.status ?? 'Good'}
                  </span>
                </div>
              </div>
            ) : (
              <div className="rounded-2xl border bg-card p-5 text-sm text-muted-foreground">
                No meals analysed yet.
              </div>
            )}
          </section>

          {/* Actions */}
          <section>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-lg font-semibold">
                Today's actions
              </h2>

              <button
                onClick={() => setCurrentScreen('tasks')}
                className="text-sm font-medium text-muted-foreground hover:text-foreground"
              >
                View all
              </button>
            </div>

            <div className="space-y-2">
              {recommendations.slice(0, 3).map(recommendation => (
                <div
                  key={recommendation.id}
                  className="flex items-center gap-3 rounded-2xl border bg-card p-4"
                >
                  <div
                    className={`h-2.5 w-2.5 rounded-full ${
                      recommendation.completed
                        ? 'bg-foreground'
                        : 'border border-foreground'
                    }`}
                  />

                  <p
                    className={`flex-1 text-sm ${
                      recommendation.completed
                        ? 'text-muted-foreground line-through'
                        : ''
                    }`}
                  >
                    {recommendation.title ??
                      recommendation.description ??
                      'Healthy action'}
                  </p>
                </div>
              ))}

              {recommendations.length === 0 && (
                <div className="rounded-2xl border bg-card p-5 text-sm text-muted-foreground">
                  Your recommendations will appear here.
                </div>
              )}
            </div>
          </section>

        </div>
      </main>

      <BottomNav />
    </div>
  )
}
