import React from 'react'
import { Flame, Dumbbell, Wheat, Droplets, HeartPulse } from 'lucide-react'
import { useMeals } from '../../context/MealContext'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card'
import { ProgressRing } from '../ui/ProgressRing'
import { cn } from '../../lib/utils'

export function StatsOverview() {
  // Mocking stats for demonstration as per current context
  const calories = 1420
  const targetCalories = 2000
  const protein = 78
  const targetProtein = 120
  const carbs = 160
  const targetCarbs = 220
  const fat = 48
  const targetFat = 65
  const healthScore = 84

  const caloriePercentage = Math.min(Math.round((calories / targetCalories) * 100), 100)

  const macros = [
    { label: 'Protein', value: protein, target: targetProtein, unit: 'g', color: 'text-primary', bg: 'bg-primary' },
    { label: 'Carbs', value: carbs, target: targetCarbs, unit: 'g', color: 'text-secondary', bg: 'bg-secondary' },
    { label: 'Fat', value: fat, target: targetFat, unit: 'g', color: 'text-accent', bg: 'bg-accent' },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Main Calorie Card */}
      <Card className="md:col-span-1 flex flex-col items-center justify-center py-8">
        <div className="relative">
          <ProgressRing progress={caloriePercentage} size={160} strokeWidth={12} />
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-3xl font-bold text-text">{calories}</span>
            <span className="text-textSecondary text-sm">/ {targetCalories} kcal</span>
          </div>
        </div>
        <CardTitle className="mt-6">Daily Calories</CardTitle>
      </Card>

      {/* Macros Grid */}
      <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-4">
        {macros.map((macro) => (
          <Card key={macro.label} className="flex flex-col justify-between">
            <div className="flex items-center gap-2 mb-2">
              <div className={cn("p-2 rounded-lg bg-surface border border-border", macro.color)}>
                {macro.label === 'Protein' && <Dumbbell size={20} />}
                {macro.label === 'Carbs' && <Wheat size={20} />}
                {macro.label === 'Fat' && <Droplets size={20} />}
              </div>
              <span className="text-textSecondary font-medium">{macro.label}</span>
            </div>
            <div>
              <div className="text-2xl font-bold text-text">{macro.value}<span className="text-sm text-textSecondary ml-1">{macro.unit}</span></div>
              <div className="w-full h-2 bg-border rounded-full mt-2 overflow-hidden">
                <div 
                  className={cn("h-full rounded-full", macro.bg)} 
                  style={{ width: `${Math.min((macro.value / macro.target) * 100, 100)}%` }} 
                />
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Health Score Card */}
      <Card className="md:col-span-3 flex items-center justify-between px-8 py-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-primary/10 rounded-full text-primary">
            <HeartPulse size={28} />
          </div>
          <div>
            <CardTitle>Daily Health Score</CardTitle>
            <p className="text-textSecondary">Your nutritional balance is looking great today!</p>
          </div>
        </div>
        <div className="text-4xl font-bold text-primary">{healthScore}/100</div>
      </Card>
    </div>
  )
}
