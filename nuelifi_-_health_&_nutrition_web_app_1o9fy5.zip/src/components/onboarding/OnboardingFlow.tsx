import { useState } from 'react';
import { ArrowRight, Check, Target, Heart, Brain, Droplets, Moon, Dumbbell } from 'lucide-react';
import { useAppState } from '../../hooks/useAppState';
import { Button } from '../ui';
import { cn } from '../../lib/utils';

const steps = [
  {
    id: 'goals',
    title: 'What are your health goals?',
    subtitle: 'Select all that apply',
    icon: Target,
    options: [
      { id: 'weight', label: 'Weight Management', icon: Dumbbell },
      { id: 'energy', label: 'Better Energy', icon: Brain },
      { id: 'inflammation', label: 'Reduce Inflammation', icon: Heart },
      { id: 'longevity', label: 'Longevity', icon: Moon },
    ],
    multi: true,
  },
  {
    id: 'dietary',
    title: 'Any dietary restrictions?',
    subtitle: 'Helps us personalize recommendations',
    icon: Droplets,
    options: [
      { id: 'gluten', label: 'Gluten-Free' },
      { id: 'dairy', label: 'Dairy-Free' },
      { id: 'vegan', label: 'Vegan/Vegetarian' },
      { id: 'lowsodium', label: 'Low Sodium' },
      { id: 'keto', label: 'Keto/Low Carb' },
      { id: 'none', label: 'None' },
    ],
    multi: true,
  },
  {
    id: 'conditions',
    title: 'Health conditions to consider?',
    subtitle: 'Optional - helps tailor advice for NCD prevention',
    icon: Heart,
    options: [
      { id: 'prediabetes', label: 'Pre-diabetes / Diabetes' },
      { id: 'hypertension', label: 'High Blood Pressure' },
      { id: 'cholesterol', label: 'High Cholesterol' },
      { id: 'heart', label: 'Heart Disease Risk' },
      { id: 'none', label: 'None / Prefer not to say' },
    ],
    multi: true,
  },
];

export function OnboardingFlow() {
  const { onboardingStep, setOnboardingStep, completeOnboarding, user } = useAppState();
  const [selections, setSelections] = useState<Record<string, string[]>>({
    goals: [],
    dietary: [],
    conditions: [],
  });

  const currentStep = steps[onboardingStep];
  const isLastStep = onboardingStep === steps.length - 1;
  const currentSelections = selections[currentStep.id] || [];

  const toggleOption = (optionId: string) => {
    setSelections(prev => {
      const current = prev[currentStep.id] || [];
      if (optionId === 'none') {
        return { ...prev, [currentStep.id]: current.includes('none') ? [] : ['none'] };
      }
      const filtered = current.filter(id => id !== 'none');
      const updated = filtered.includes(optionId)
        ? filtered.filter(id => id !== optionId)
        : [...filtered, optionId];
      return { ...prev, [currentStep.id]: updated };
    });
  };

  const handleNext = () => {
    if (isLastStep) {
      completeOnboarding();
    } else {
      setOnboardingStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    setOnboardingStep(prev => Math.max(0, prev - 1));
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-12 md:py-20">
        <div className="w-full max-w-md">
          <div className="mb-8 text-center">
            <div className="flex items-center justify-center gap-2 mb-6">
              {steps.map((_, i) => (
                <div
                  key={i}
                  className={cn(
                    'w-2 h-2 rounded-full transition-all duration-300',
                    i < onboardingStep ? 'bg-primary' :
                    i === onboardingStep ? 'bg-primary' : 'bg-border'
                  )}
                />
              ))}
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-text mb-2">
              {currentStep.title}
            </h2>
            <p className="text-textSecondary text-lg">{currentStep.subtitle}</p>
          </div>

          <div className="space-y-3">
            {currentStep.options.map((option) => (
              <button
                key={option.id}
                onClick={() => toggleOption(option.id)}
                className={cn(
                  'w-full p-4 rounded-xl border-2 text-left transition-all duration-200',
                  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50',
                  currentSelections.includes(option.id)
                    ? 'border-primary bg-primary/5 text-text'
                    : 'border-border bg-surface hover:border-primary/50 hover:bg-surface/50 text-textSecondary'
                )}
              >
                <div className="flex items-center gap-3">
                  {option.icon && (
                    <option.icon className={cn(
                      'w-5 h-5 flex-shrink-0',
                      currentSelections.includes(option.id) ? 'text-primary' : 'text-textSecondary'
                    )} aria-hidden="true" />
                  )}
                  <span className="font-medium">{option.label}</span>
                  {currentSelections.includes(option.id) && (
                    <Check className="ml-auto w-5 h-5 text-primary flex-shrink-0" />
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4 md:p-6 border-t border-border bg-background/50 backdrop-blur-xl safe-area-pb">
        <div className="flex items-center justify-between gap-4 max-w-md mx-auto w-full">
          <Button
            variant="ghost"
            size="lg"
            onClick={handleBack}
            disabled={onboardingStep === 0}
            className="flex-1"
          >
            Back
          </Button>
          <Button
            size="lg"
            onClick={handleNext}
            disabled={currentSelections.length === 0}
            className="flex-1"
          >
            {isLastStep ? 'Get Started' : 'Continue'}
            <ArrowRight className="w-5 h-5" aria-hidden="true" />
          </Button>
        </div>
      </div>
    </div>
  );
}
