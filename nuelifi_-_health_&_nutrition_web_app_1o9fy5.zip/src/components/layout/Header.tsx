import { useAppState } from '../../hooks/useAppState'

export function Header() {
  const { user, setCurrentScreen } = useAppState()

  return (
    <header className="sticky top-0 z-30 border-b bg-background/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4 md:px-6">

        <button
          onClick={() => setCurrentScreen('dashboard')}
          className="flex items-center gap-2"
          aria-label="Go to dashboard"
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-foreground text-sm font-bold text-background">
            N
          </div>

          <span className="text-lg font-semibold tracking-tight">
            Nuelifi
          </span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            className="flex h-9 w-9 items-center justify-center rounded-xl border text-sm transition-colors hover:bg-muted"
            aria-label="Notifications"
          >
            •
          </button>

          <button
            type="button"
            onClick={() => setCurrentScreen('settings')}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-sm font-medium transition-colors hover:bg-muted/70"
            aria-label="Open profile"
          >
            {user?.name?.charAt(0)?.toUpperCase() ?? 'U'}
          </button>
        </div>

      </div>
    </header>
  )
}

export default Header
