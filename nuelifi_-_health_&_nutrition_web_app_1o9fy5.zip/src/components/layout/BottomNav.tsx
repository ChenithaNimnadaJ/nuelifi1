import { useAppState } from '../../hooks/useAppState';
import { Home, Camera, ClipboardList, BarChart3, Settings, User } from 'lucide-react';
import { cn } from '../../lib/utils';

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Home },
  { id: 'camera', label: 'Snap', icon: Camera, isAction: true },
  { id: 'tasks', label: 'Tasks', icon: ClipboardList },
  { id: 'analysis', label: 'Analysis', icon: BarChart3 },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function BottomNav() {
  const { currentScreen, setCurrentScreen } = useAppState();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-surface/95 backdrop-blur-xl border-t border-border safe-area-pb">
      <div className="flex items-center justify-around h-16 md:h-14">
        {navItems.map((item) => {
          const isActive = currentScreen === item.id;
          const Icon = item.icon;
          
          if (item.isAction) {
            return (
              <button
                key={item.id}
                onClick={() => setCurrentScreen('camera')}
                className={cn(
                  'relative z-10 flex flex-col items-center gap-1',
                  'w-16 h-16 md:w-14 md:h-14 rounded-2xl',
                  'bg-primary text-white shadow-xl shadow-primary/30',
                  'hover:scale-105 active:scale-95 transition-transform duration-150',
                  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50'
                )}
                aria-label={item.label}
              >
                <Icon className="w-7 h-7 md:w-6 md:h-6" aria-hidden="true" />
                <span className="text-xs font-medium hidden md:block">Snap</span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => setCurrentScreen(item.id)}
              className={cn(
                'flex flex-col items-center gap-1 px-3 py-2',
                'rounded-xl transition-all duration-200',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50',
                isActive
                  ? 'text-primary bg-primary/10'
                  : 'text-textSecondary hover:text-text hover:bg-surface'
              )}
              aria-label={item.label}
              aria-current={isActive ? 'page' : undefined}
            >
              <Icon className={cn('w-6 h-6 md:w-5 md:h-5', isActive && 'fill-current')} aria-hidden="true" />
              <span className="text-xs font-medium hidden md:block">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
