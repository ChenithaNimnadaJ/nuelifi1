import {
  createContext,
  useContext,
  useState,
  type ReactNode,
} from 'react'
import {
  Meal,
  Recommendation,
  UserProfile,
  DailyStats,
} from '../types'
import {
  mockUser,
  mockMeals,
  mockRecommendations,
  mockDailyStats,
} from '../data/mockData'

interface AppState {
  user: UserProfile
  meals: Meal[]
  recommendations: Recommendation[]
  dailyStats: DailyStats
  currentScreen: string
  onboardingStep: number
  isOnboardingComplete: boolean
  setCurrentScreen: (screen: string) => void
  setOnboardingStep: (step: number) => void
  completeOnboarding: () => void
  addMeal: (meal: Meal) => void
  updateRecommendation: (id: string, completed: boolean) => void
  upgradeToPro: () => void
}

const AppStateContext = createContext<AppState | undefined>(undefined)

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile>(mockUser)
  const [meals, setMeals] = useState<Meal[]>(mockMeals)
  const [recommendations, setRecommendations] =
    useState<Recommendation[]>(mockRecommendations)
  const [dailyStats] = useState<DailyStats>(mockDailyStats)

  const [currentScreen, setCurrentScreen] =
    useState<string>('onboarding')

  const [onboardingStep, setOnboardingStep] = useState(0)
  const [isOnboardingComplete, setIsOnboardingComplete] =
    useState(false)

  const completeOnboarding = () => {
    setIsOnboardingComplete(true)
    setCurrentScreen('dashboard')
  }

  const addMeal = (meal: Meal) => {
    setMeals(prev => [meal, ...prev])
    setRecommendations(prev => [
      ...prev,
      ...(meal.recommendations || []),
    ])
  }

  const updateRecommendation = (
    id: string,
    completed: boolean,
  ) => {
    setRecommendations(prev =>
      prev.map(item =>
        item.id === id ? { ...item, completed } : item,
      ),
    )
  }

  const upgradeToPro = () => {
    setUser(prev => ({
      ...prev,
      plan: 'pro',
    }))
  }

  return (
    <AppStateContext.Provider
      value={{
        user,
        meals,
        recommendations,
        dailyStats,
        currentScreen,
        onboardingStep,
        isOnboardingComplete,
        setCurrentScreen,
        setOnboardingStep,
        completeOnboarding,
        addMeal,
        updateRecommendation,
        upgradeToPro,
      }}
    >
      {children}
    </AppStateContext.Provider>
  )
}

export function useAppState() {
  const context = useContext(AppStateContext)

  if (!context) {
    throw new Error(
      'useAppState must be used within AppStateProvider',
    )
  }

  return context
}
