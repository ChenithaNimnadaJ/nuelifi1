import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react'
import { Task } from '../types'
import { mockTasks } from '../mock/data'

interface TaskContextType {
  tasks: Task[]
  toggleTask: (id: string) => void
  addTask: (task: Omit<Task, 'id' | 'userId'>) => void
  getTasksForToday: () => Task[]
  getUpcomingTasks: () => Task[]
  getCompletedCount: () => number
  getTotalCount: () => number
}

const TaskContext = createContext<TaskContextType | undefined>(undefined)

export function TaskProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>(() => {
    try {
      const stored = localStorage.getItem('nuelifi_tasks')
      if (stored) {
        return JSON.parse(stored, (key, value) => {
          if (key === 'dueDate' || key === 'completedAt') {
            return new Date(value)
          }
          return value
        })
      }
    } catch {
      // Fall back to mock data
    }

    return mockTasks
  })

  useEffect(() => {
    localStorage.setItem('nuelifi_tasks', JSON.stringify(tasks))
  }, [tasks])

  const toggleTask = useCallback((id: string) => {
    setTasks(prev =>
      prev.map(task => {
        if (task.id !== id) return task

        if (task.completed) {
          return {
            ...task,
            completed: false,
            completedAt: undefined,
            streak: Math.max(0, task.streak - 1),
          }
        }

        return {
          ...task,
          completed: true,
          completedAt: new Date(),
          streak: task.streak + 1,
        }
      }),
    )
  }, [])

  const addTask = useCallback(
    (task: Omit<Task, 'id' | 'userId'>) => {
      const newTask: Task = {
        ...task,
        id: `task-${Date.now()}`,
        userId: 'user-1',
      }

      setTasks(prev => [newTask, ...prev])
    },
    [],
  )

  const getTasksForToday = useCallback(() => {
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)

    return tasks.filter(
      task => task.dueDate >= today && task.dueDate < tomorrow,
    )
  }, [tasks])

  const getUpcomingTasks = useCallback(() => {
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    return tasks
      .filter(task => !task.completed && task.dueDate >= today)
      .sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime())
  }, [tasks])

  const getCompletedCount = useCallback(
    () => tasks.filter(task => task.completed).length,
    [tasks],
  )

  const getTotalCount = useCallback(() => tasks.length, [tasks])

  return (
    <TaskContext.Provider
      value={{
        tasks,
        toggleTask,
        addTask,
        getTasksForToday,
        getUpcomingTasks,
        getCompletedCount,
        getTotalCount,
      }}
    >
      {children}
    </TaskContext.Provider>
  )
}

export function useTasks() {
  const context = useContext(TaskContext)

  if (!context) {
    throw new Error('useTasks must be used within TaskProvider')
  }

  return context
}
