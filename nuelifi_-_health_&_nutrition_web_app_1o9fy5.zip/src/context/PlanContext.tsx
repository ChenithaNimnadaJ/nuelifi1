import { createContext, useContext, useState, ReactNode, useCallback } from 'react'
import { PlanTier } from '../types'
import { planTiers } from '../mock/data'

interface PlanContextType {
  currentPlan: PlanTier
  setPlan: (planId: 'free' | 'pro') => void
  canScan: () => boolean
  getScansUsed: () => number
  getScansLimit: () => number
}

const PlanContext = createContext<PlanContextType | undefined>(undefined)

export function PlanProvider({ children }: { children: ReactNode }) {
  const [currentPlan, setCurrentPlan] = useState<PlanTier>(() => {
    const stored = localStorage.getItem('nuelifi_plan')
    if (stored) return JSON.parse(stored)
    return planTiers[0]
  })

  const setPlan = useCallback((planId: 'free' | 'pro') => {
    const plan = planTiers.find(p => p.id === planId)
    if (plan) {
      setCurrentPlan(plan)
      localStorage.setItem('nuelifi_plan', JSON.stringify(plan))
    }
  }, [])

  const getScansUsed = useCallback(() => {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const stored = localStorage.getItem('nuelifi_scans')
    if (!stored) return 0
    const data = JSON.parse(stored)
    if (data.date !== today.toISOString()) return 0
    return data.count
  }, [])

  const canScan = useCallback(() => {
    if (currentPlan.limits.dailyScans === -1) return true
    return getScansUsed() < currentPlan.limits.dailyScans
  }, [currentPlan, getScansUsed])

  const getScansLimit = useCallback(() => currentPlan.limits.dailyScans, [currentPlan])

  return (
    <PlanContext.Provider value={{ currentPlan, setPlan, canScan, getScansUsed, getScansLimit }}>
      {children}
    </PlanContext.Provider>
  )
}

export function usePlan() {
  const context = useContext(PlanContext)
  if (!context) throw new Error('usePlan must be used within PlanProvider')
  return context
}
