import { createContext, useContext, useState, ReactNode, useCallback, useEffect } from 'react'
import { OnboardingStep } from '../types'
import { onboardingSteps, healthGoals, dietaryOptions } from '../mock/data'

interface OnboardingContextType {
  steps: OnboardingStep[]
  currentStepIndex: number
  currentStep: OnboardingStep
  isComplete: boolean
  formData: {
    goals: string[]
    dietary: string[]
    baseline: { mealsPerDay: number; cookingFrequency: string; waterIntake: string }
  }
  nextStep: () => void
  prevStep: () => void
  setGoals: (goals: string[]) => void
  setDietary: (dietary: string[]) => void
  setBaseline: (baseline: any) => void
  completeOnboarding: () => void
  resetOnboarding: () => void
}

const OnboardingContext = createContext<OnboardingContextType | undefined>(undefined)

export function OnboardingProvider({ children }: { children: ReactNode }) {
  const [steps, setSteps] = useState<OnboardingStep[]>(() => {
    const stored = localStorage.getItem('nuelifi_onboarding')
    if (stored) return JSON.parse(stored)
    return onboardingSteps
  })
  const [currentStepIndex, setCurrentStepIndex] = useState(0)
  const [formData, setFormData] = useState({
    goals: [] as string[],
    dietary: [] as string[],
    baseline: { mealsPerDay: 3, cookingFrequency: 'sometimes', waterIntake: 'moderate' }
  })

  useEffect(() => {
    const stored = localStorage.getItem('nuelifi_onboarding_data')
    if (stored) setFormData(JSON.parse(stored))
    const stepStored = localStorage.getItem('nuelifi_onboarding_step')
    if (stepStored) setCurrentStepIndex(parseInt(stepStored))
  }, [])

  useEffect(() => {
    localStorage.setItem('nuelifi_onboarding', JSON.stringify(steps))
    localStorage.setItem('nuelifi_onboarding_step', currentStepIndex.toString())
    localStorage.setItem('nuelifi_onboarding_data', JSON.stringify(formData))
  }, [steps, currentStepIndex, formData])

  const currentStep = steps[currentStepIndex]
  const isComplete = steps.every(s => s.completed)

  const nextStep = useCallback(() => {
    setSteps(prev => prev.map((s, i) => i === currentStepIndex ? { ...s, completed: true } : s))
    setCurrentStepIndex(prev => Math.min(prev + 1, steps.length - 1))
  }, [currentStepIndex, steps.length])

  const prevStep = useCallback(() => {
    setCurrentStepIndex(prev => Math.max(prev - 1, 0))
  }, [])

  const setGoals = useCallback((goals: string[]) => {
    setFormData(prev => ({ ...prev, goals }))
  }, [])

  const setDietary = useCallback((dietary: string[]) => {
    setFormData(prev => ({ ...prev, dietary }))
  }, [])

  const setBaseline = useCallback((baseline: any) => {
    setFormData(prev => ({ ...prev, baseline }))
  }, [])

  const completeOnboarding = useCallback(() => {
    setSteps(prev => prev.map(s => ({ ...s, completed: true })))
    localStorage.setItem('nuelifi_onboarding_complete', 'true')
  }, [])

  const resetOnboarding = useCallback(() => {
    setSteps(onboardingSteps)
    setCurrentStepIndex(0)
    setFormData({ goals: [], dietary: [], baseline: { mealsPerDay: 3, cookingFrequency: 'sometimes', waterIntake: 'moderate' } })
    localStorage.removeItem('nuelifi_onboarding_complete')
  }, [])

  return (
    <OnboardingContext.Provider value={{ steps, currentStepIndex, currentStep, isComplete, formData, nextStep, prevStep, setGoals, setDietary, setBaseline, completeOnboarding, resetOnboarding }}>
      {children}
    </OnboardingContext.Provider>
  )
}

export function useOnboarding() {
  const context = useContext(OnboardingContext)
  if (!context) throw new Error('useOnboarding must be used within OnboardingProvider')
  return context
}
