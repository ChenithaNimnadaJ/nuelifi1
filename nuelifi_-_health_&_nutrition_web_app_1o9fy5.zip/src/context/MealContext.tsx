import { createContext, useContext, useState, ReactNode, useCallback, useEffect } from 'react'
import { Meal, MealAnalysis } from '../types'
import { mockMeals } from '../mock/data'

interface MealContextType {
  meals: Meal[]
  currentMeal: Meal | null
  isAnalyzing: boolean
  addMeal: (imageUrl: string) => Promise<Meal>
  analyzeMeal: (mealId: string, analysis: MealAnalysis) => void
  getMealsByDate: (date: Date) => Meal[]
  getRecentMeals: (limit?: number) => Meal[]
  deleteMeal: (id: string) => void
}

const MealContext = createContext<MealContextType | undefined>(undefined)

export function MealProvider({ children }: { children: ReactNode }) {
  const [meals, setMeals] = useState<Meal[]>(() => {
    const stored = localStorage.getItem('nuelifi_meals')
    return stored ? JSON.parse(stored, (key, value) => {
      if (key === 'timestamp') return new Date(value)
      return value
    }) : mockMeals
  })
  const [currentMeal, setCurrentMeal] = useState<Meal | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  useEffect(() => {
    localStorage.setItem('nuelifi_meals', JSON.stringify(meals))
  }, [meals])

  const addMeal = useCallback(async (imageUrl: string): Promise<Meal> => {
    const newMeal: Meal = {
      id: `meal-${Date.now()}`,
      userId: 'user-1',
      imageUrl,
      timestamp: new Date(),
      status: 'pending',
      analysis: {} as MealAnalysis
    }
    setMeals(prev => [newMeal, ...prev])
    setCurrentMeal(newMeal)
    return newMeal
  }, [])

  const analyzeMeal = useCallback((mealId: string, analysis: MealAnalysis) => {
    setMeals(prev => prev.map(meal => 
      meal.id === mealId ? { ...meal, analysis, status: 'analyzed' as const } : meal
    ))
    setIsAnalyzing(false)
  }, [])

  const getMealsByDate = useCallback((date: Date) => {
    const start = new Date(date)
    start.setHours(0, 0, 0, 0)
    const end = new Date(date)
    end.setHours(23, 59, 59, 999)
    return meals.filter(m => m.timestamp >= start && m.timestamp <= end)
  }, [meals])

  const getRecentMeals = useCallback((limit = 5) => {
    return [...meals].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()).slice(0, limit)
  }, [meals])

  const deleteMeal = useCallback((id: string) => {
    setMeals(prev => prev.filter(m => m.id !== id))
  }, [])

  return (
    <MealContext.Provider value={{ meals, currentMeal, isAnalyzing, addMeal, analyzeMeal, getMealsByDate, getRecentMeals, deleteMeal }}>
      {children}
    </MealContext.Provider>
  )
}

export function useMeals() {
  const context = useContext(MealContext)
  if (!context) throw new Error('useMeals must be used within MealProvider')
  return context
}
