import { AuthProvider } from './context/AuthContext'
import { MealProvider } from './context/MealContext'
import { TaskProvider } from './context/TaskContext'
import { PlanProvider } from './context/PlanContext'
import { OnboardingProvider } from './context/OnboardingContext'
import { AppStateProvider } from './hooks/useAppState'
import Layout from './components/Layout'
import './index.css'

function App() {
  return (
    <AuthProvider>
      <OnboardingProvider>
        <PlanProvider>
          <MealProvider>
            <TaskProvider>
              <AppStateProvider>
                <Layout />
              </AppStateProvider>
            </TaskProvider>
          </MealProvider>
        </PlanProvider>
      </OnboardingProvider>
    </AuthProvider>
  )
}

export default App
