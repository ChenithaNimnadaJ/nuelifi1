export interface User {
  id: string
  name: string
  email: string
  avatar?: string
  plan: 'free' | 'pro'
  onboardingComplete: boolean
  preferences: {
    dietaryRestrictions: string[]
    healthGoals: string[]
    notifications: boolean
    units: 'metric' | 'imperial'
  }
}

export interface Meal {
  id: string
  userId: string
  imageUrl: string
  timestamp: Date
  analysis: MealAnalysis
  status: 'pending' | 'analyzed' | 'failed'
}

export interface MealAnalysis {
  mealName: string
  calories: number
  macros: {
    protein: number
    carbs: number
    fat: number
    fiber: number
    sugar: number
    sodium: number
  }
  healthScore: number
  status: 'excellent' | 'good' | 'moderate' | 'poor'
  insights: string[]
  recommendations: string[]
  modifications: MealModification[]
  nutrients: NutrientBreakdown[]
}

export interface MealModification {
  original: string
  suggested: string
  reason: string
  impact: 'high' | 'medium' | 'low'
}

export interface NutrientBreakdown {
  name: string
  value: number
  unit: string
  dailyValue: number
  status: 'optimal' | 'adequate' | 'low' | 'high'
}

export interface Task {
  id: string
  userId: string
  title: string
  description: string
  category: 'nutrition' | 'hydration' | 'activity' | 'mindfulness'
  frequency: 'daily' | 'weekly' | 'custom'
  completed: boolean
  completedAt?: Date
  streak: number
  sourceMealId?: string
  priority: 'high' | 'medium' | 'low'
  dueDate: Date
}

export interface Insight {
  id: string
  type: 'trend' | 'pattern' | 'achievement' | 'warning'
  title: string
  description: string
  metric: string
  value: number
  change: number
  period: 'day' | 'week' | 'month'
  relatedMealIds?: string[]
}

export interface PlanTier {
  id: 'free' | 'pro'
  name: string
  price: number
  period: 'month' | 'year'
  features: string[]
  limits: {
    dailyScans: number
    historyDays: number
    insights: boolean
    exportData: boolean
    prioritySupport: boolean
  }
}

export interface OnboardingStep {
  id: string
  title: string
  subtitle: string
  component: string
  completed: boolean
}

export type Screen = 'onboarding' | 'dashboard' | 'camera' | 'analysis' | 'tasks' | 'insights' | 'settings' | 'plan'
