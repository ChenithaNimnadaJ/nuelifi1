import { User, Meal, Task, Insight, PlanTier, OnboardingStep } from '../types'

export const mockUser: User = {
  id: 'user-1',
  name: 'Alex Chen',
  email: 'alex@nuelifi.com',
  plan: 'free',
  onboardingComplete: true,
  preferences: {
    dietaryRestrictions: ['vegetarian', 'low-sodium'],
    healthGoals: ['weight-management', 'energy', 'longevity'],
    notifications: true,
    units: 'metric'
  }
}

export const mockMeals: Meal[] = [
  {
    id: 'meal-1',
    userId: 'user-1',
    imageUrl: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?w=400',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    status: 'analyzed',
    analysis: {
      mealName: 'Mediterranean Quinoa Bowl',
      calories: 420,
      macros: { protein: 18, carbs: 52, fat: 14, fiber: 12, sugar: 8, sodium: 380 },
      healthScore: 92,
      status: 'excellent',
      insights: [
        'Excellent protein-to-carb ratio for sustained energy',
        'High fiber content supports digestive health',
        'Rich in antioxidants from colorful vegetables',
        'Omega-3s from walnuts support brain health'
      ],
      recommendations: [
        'Add a side of fermented vegetables for gut health',
        'Consider a post-meal walk to optimize glucose response'
      ],
      modifications: [
        { original: 'White quinoa', suggested: 'Tri-color quinoa', reason: 'Higher antioxidant variety', impact: 'low' },
        { original: 'Regular feta', suggested: 'Reduced-sodium feta', reason: 'Lower sodium for blood pressure', impact: 'medium' }
      ],
      nutrients: [
        { name: 'Vitamin C', value: 85, unit: 'mg', dailyValue: 90, status: 'optimal' },
        { name: 'Iron', value: 4.2, unit: 'mg', dailyValue: 18, status: 'adequate' },
        { name: 'Magnesium', value: 120, unit: 'mg', dailyValue: 400, status: 'adequate' },
        { name: 'Potassium', value: 780, unit: 'mg', dailyValue: 4700, status: 'low' },
        { name: 'Vitamin B12', value: 0.8, unit: 'mcg', dailyValue: 2.4, status: 'low' }
      ]
    }
  },
  {
    id: 'meal-2',
    userId: 'user-1',
    imageUrl: 'https://images.pexels.com/photos/1099680/pexels-photo-1099680.jpeg?w=400',
    timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
    status: 'analyzed',
    analysis: {
      mealName: 'Grilled Salmon with Roasted Vegetables',
      calories: 580,
      macros: { protein: 42, carbs: 28, fat: 32, fiber: 9, sugar: 6, sodium: 420 },
      healthScore: 88,
      status: 'good',
      insights: [
        'High-quality protein for muscle maintenance',
        'Omega-3 fatty acids support cardiovascular health',
        'Good variety of phytonutrients from mixed vegetables'
      ],
      recommendations: [
        'Reduce added salt in preparation',
        'Add leafy greens for more folate and vitamin K'
      ],
      modifications: [
        { original: 'Olive oil drizzle', suggested: 'Measure 1 tsp olive oil', reason: 'Control calorie density', impact: 'medium' },
        { original: 'Salt seasoning', suggested: 'Herb blend (rosemary, thyme, garlic)', reason: 'Reduce sodium by 300mg', impact: 'high' }
      ],
      nutrients: [
        { name: 'Omega-3', value: 2.3, unit: 'g', dailyValue: 1.6, status: 'optimal' },
        { name: 'Vitamin D', value: 12, unit: 'mcg', dailyValue: 20, status: 'adequate' },
        { name: 'Selenium', value: 55, unit: 'mcg', dailyValue: 55, status: 'optimal' },
        { name: 'Vitamin B6', value: 1.2, unit: 'mg', dailyValue: 1.7, status: 'adequate' }
      ]
    }
  },
  {
    id: 'meal-3',
    userId: 'user-1',
    imageUrl: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?w=400',
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
    status: 'analyzed',
    analysis: {
      mealName: 'Chicken Caesar Wrap',
      calories: 650,
      macros: { protein: 35, carbs: 45, fat: 34, fiber: 4, sugar: 5, sodium: 1280 },
      healthScore: 54,
      status: 'moderate',
      insights: [
        'High sodium content exceeds daily recommendation',
        'Low fiber for a main meal',
        'Processed dressing adds hidden sugars and preservatives'
      ],
      recommendations: [
        'Swap wrap for whole grain or lettuce wrap',
        'Use Greek yogurt-based dressing',
        'Add more vegetables to increase fiber'
      ],
      modifications: [
        { original: 'Caesar dressing', suggested: 'Greek yogurt + lemon + anchovy paste', reason: 'Cut calories by 120, sodium by 400mg', impact: 'high' },
        { original: 'White flour wrap', suggested: 'Sprouted grain wrap', reason: 'Add 6g fiber, lower glycemic index', impact: 'high' },
        { original: 'Parmesan cheese', suggested: 'Nutritional yeast', reason: 'B12 boost, lower sodium', impact: 'medium' }
      ],
      nutrients: [
        { name: 'Sodium', value: 1280, unit: 'mg', dailyValue: 2300, status: 'high' },
        { name: 'Protein', value: 35, unit: 'g', dailyValue: 50, status: 'adequate' },
        { name: 'Fiber', value: 4, unit: 'g', dailyValue: 28, status: 'low' },
        { name: 'Calcium', value: 280, unit: 'mg', dailyValue: 1000, status: 'adequate' }
      ]
    }
  },
  {
    id: 'meal-4',
    userId: 'user-1',
    imageUrl: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?w=400',
    timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000),
    status: 'analyzed',
    analysis: {
      mealName: 'Acai Bowl with Granola',
      calories: 480,
      macros: { protein: 12, carbs: 78, fat: 16, fiber: 14, sugar: 42, sodium: 85 },
      healthScore: 71,
      status: 'moderate',
      insights: [
        'High natural sugar from fruit and granola',
        'Good antioxidant profile from acai and berries',
        'Low protein for a meal replacement'
      ],
      recommendations: [
        'Add protein powder or Greek yogurt base',
        'Reduce granola portion, increase nuts/seeds',
        'Choose unsweetened acai puree'
      ],
      modifications: [
        { original: 'Sweetened granola', suggested: 'Raw nuts + seeds + cinnamon', reason: 'Cut 15g sugar, add healthy fats', impact: 'high' },
        { original: 'Honey drizzle', suggested: 'Skip or use monk fruit', reason: 'Reduce added sugar', impact: 'medium' }
      ],
      nutrients: [
        { name: 'Vitamin C', value: 120, unit: 'mg', dailyValue: 90, status: 'optimal' },
        { name: 'Antioxidants', value: 8500, unit: 'ORAC', dailyValue: 5000, status: 'optimal' },
        { name: 'Sugar', value: 42, unit: 'g', dailyValue: 50, status: 'high' },
        { name: 'Protein', value: 12, unit: 'g', dailyValue: 50, status: 'low' }
      ]
    }
  }
]

export const mockTasks: Task[] = [
  {
    id: 'task-1',
    userId: 'user-1',
    title: 'Add fermented food to one meal',
    description: 'Support gut microbiome with kimchi, sauerkraut, or kefir',
    category: 'nutrition',
    frequency: 'daily',
    completed: false,
    streak: 3,
    sourceMealId: 'meal-1',
    priority: 'high',
    dueDate: new Date(Date.now() + 12 * 60 * 60 * 1000)
  },
  {
    id: 'task-2',
    userId: 'user-1',
    title: 'Post-meal 10-minute walk',
    description: 'Improve glucose response and digestion',
    category: 'activity',
    frequency: 'daily',
    completed: true,
    completedAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
    streak: 7,
    sourceMealId: 'meal-1',
    priority: 'high',
    dueDate: new Date()
  },
  {
    id: 'task-3',
    userId: 'user-1',
    title: 'Drink 2L water today',
    description: 'Stay hydrated for optimal metabolism',
    category: 'hydration',
    frequency: 'daily',
    completed: false,
    streak: 12,
    priority: 'medium',
    dueDate: new Date(Date.now() + 8 * 60 * 60 * 1000)
  },
  {
    id: 'task-4',
    userId: 'user-1',
    title: 'Reduce sodium at dinner',
    description: 'Use herbs instead of salt based on your last meal analysis',
    category: 'nutrition',
    frequency: 'daily',
    completed: false,
    streak: 1,
    sourceMealId: 'meal-3',
    priority: 'high',
    dueDate: new Date(Date.now() + 6 * 60 * 60 * 1000)
  },
  {
    id: 'task-5',
    userId: 'user-1',
    title: 'Mindful eating practice',
    description: 'Eat without screens, chew 20x per bite',
    category: 'mindfulness',
    frequency: 'daily',
    completed: false,
    streak: 0,
    priority: 'medium',
    dueDate: new Date(Date.now() + 10 * 60 * 60 * 1000)
  },
  {
    id: 'task-6',
    userId: 'user-1',
    title: 'Weekly meal prep session',
    description: 'Prepare 3 healthy meals for the week',
    category: 'nutrition',
    frequency: 'weekly',
    completed: false,
    streak: 2,
    priority: 'medium',
    dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000)
  }
]

export const mockInsights: Insight[] = [
  {
    id: 'insight-1',
    type: 'trend',
    title: 'Health Score Improving',
    description: 'Your average meal health score increased 12% this week',
    metric: 'Average Health Score',
    value: 76,
    change: 12,
    period: 'week',
    relatedMealIds: ['meal-1', 'meal-2', 'meal-3', 'meal-4']
  },
  {
    id: 'insight-2',
    type: 'pattern',
    title: 'Sodium Spikes at Lunch',
    description: '3 of 4 high-sodium meals occurred at lunch - consider packed meals',
    metric: 'Lunch Sodium Avg',
    value: 980,
    change: -15,
    period: 'week',
    relatedMealIds: ['meal-3']
  },
  {
    id: 'insight-3',
    type: 'achievement',
    title: '7-Day Walk Streak!',
    description: 'Consistent post-meal walks improving metabolic health',
    metric: 'Activity Streak',
    value: 7,
    change: 7,
    period: 'week'
  },
  {
    id: 'insight-4',
    type: 'warning',
    title: 'Fiber Below Target',
    description: 'Averaging 18g/day vs 28g target - add legumes or whole grains',
    metric: 'Daily Fiber',
    value: 18,
    change: -2,
    period: 'week',
    relatedMealIds: ['meal-3', 'meal-4']
  },
  {
    id: 'insight-5',
    type: 'trend',
    title: 'Protein Consistency',
    description: 'Meeting protein goals 85% of days this month',
    metric: 'Protein Target Days',
    value: 85,
    change: 5,
    period: 'month'
  }
]

export const planTiers: PlanTier[] = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    period: 'month',
    features: [
      '3 meal scans per day',
      '7-day history',
      'Basic nutrition insights',
      'Daily task tracking',
      'Community support'
    ],
    limits: {
      dailyScans: 3,
      historyDays: 7,
      insights: false,
      exportData: false,
      prioritySupport: false
    }
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 1,
    period: 'month',
    features: [
      'Unlimited meal scans',
      'Unlimited history',
      'Advanced AI insights & trends',
      'Personalized meal modifications',
      'Data export (CSV, PDF)',
      'Priority support',
      'Meal planning & grocery lists',
      'Nutrient timing optimization',
      'Family sharing (up to 4)'
    ],
    limits: {
      dailyScans: -1,
      historyDays: -1,
      insights: true,
      exportData: true,
      prioritySupport: true
    }
  }
]

export const onboardingSteps: OnboardingStep[] = [
  { id: 'welcome', title: 'Welcome to Nuelifi', subtitle: 'Your personal nutrition intelligence', component: 'WelcomeStep', completed: false },
  { id: 'goals', title: 'Health Goals', subtitle: 'What matters most to you?', component: 'GoalsStep', completed: false },
  { id: 'dietary', title: 'Dietary Preferences', subtitle: 'Help us personalize your insights', component: 'DietaryStep', completed: false },
  { id: 'baseline', title: 'Current Habits', subtitle: 'Quick baseline assessment', component: 'BaselineStep', completed: false },
  { id: 'plan', title: 'Choose Your Plan', subtitle: 'Start free or unlock Pro', component: 'PlanStep', completed: false }
]

export const healthGoals = [
  { id: 'weight-management', label: 'Weight Management', icon: 'target', description: 'Lose, gain, or maintain weight' },
  { id: 'energy', label: 'Energy & Vitality', icon: 'zap', description: 'Sustained energy throughout the day' },
  { id: 'longevity', label: 'Longevity', icon: 'heart-pulse', description: 'Long-term health optimization' },
  { id: 'performance', label: 'Athletic Performance', icon: 'dumbbell', description: 'Optimize for training & recovery' },
  { id: 'digestion', label: 'Digestive Health', icon: 'activity', description: 'Improve gut health & regularity' },
  { id: 'mental-clarity', label: 'Mental Clarity', icon: 'brain', description: 'Focus, mood & cognitive function' }
]

export const dietaryOptions = [
  { id: 'vegetarian', label: 'Vegetarian', description: 'No meat or fish' },
  { id: 'vegan', label: 'Vegan', description: 'No animal products' },
  { id: 'pescatarian', label: 'Pescatarian', description: 'Fish but no meat' },
  { id: 'keto', label: 'Keto/Low Carb', description: 'Very low carbohydrate' },
  { id: 'mediterranean', label: 'Mediterranean', description: 'Plant-forward, healthy fats' },
  { id: 'gluten-free', label: 'Gluten-Free', description: 'No gluten-containing grains' },
  { id: 'dairy-free', label: 'Dairy-Free', description: 'No dairy products' },
  { id: 'low-sodium', label: 'Low Sodium', description: 'Restricted salt intake' },
  { id: 'low-fodmap', label: 'Low FODMAP', description: 'For IBS/sensitive digestion' },
  { id: 'halal', label: 'Halal', description: 'Islamic dietary guidelines' },
  { id: 'kosher', label: 'Kosher', description: 'Jewish dietary guidelines' },
  { id: 'none', label: 'No Restrictions', description: 'Eat everything' }
]
